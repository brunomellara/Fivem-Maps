fx_version 'bodacious'
game 'gta5'

files {
    'stream/prop_car_airbag.ytyp',
}
data_file 'DLC_ITYP_REQUEST' 'stream/prop_car_airbag.ytyp'

client_script 'cl_airbag.lua'



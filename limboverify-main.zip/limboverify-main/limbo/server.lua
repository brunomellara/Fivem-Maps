local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")

droyen = {}
Tunnel.bindInterface("limbo",droyen)

webhooklimbo = "SUA WEBHOOK"

Citizen.CreateThread(function()
	function SendWebhookMessage(webhook,message)
		if webhook ~= "none" then
			PerformHttpRequest(webhook, function(err, text, headers) end, 'POST', json.encode({content = message}), { ['Content-Type'] = 'application/json' })
		end
	end
end)

function droyen.playerLimbo(cds,carroCheck,carroName,ultimoCarro)
    local source = source
    local user_id = vRP.getUserId(source)
    if user_id then
        if carroName ~= nil then
            SendWebhookMessage(webhooklimbo,"```ini\n[ ID ]: "..user_id.."\n[LIMBO CDS]:\n"..cds.."\n  \n[ No Veiculo ]: ".. carroCheck .."\n[ Nome do veículo ]: "..carroName.."```")
        else
            if ultimoCarro ~= 'CARNOTFOUND' then
                SendWebhookMessage(webhooklimbo,"```ini\n[ ID ]: "..user_id.."\n[LIMBO CDS]:\n"..cds.."\n  \n[ No Veiculo ]: ".. carroCheck .."\n[ Ultimo Carro ]: "..ultimoCarro.."```")
            else
                SendWebhookMessage(webhooklimbo,"```ini\n[ ID ]: "..user_id.."\n[LIMBO CDS]:\n"..cds.."\n  \n[ No Veiculo ]: ".. carroCheck .."\n[ Ultimo Carro ]: Não identificado```")
            end
        end
    end
end 
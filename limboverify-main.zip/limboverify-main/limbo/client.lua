local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy['getInterface']("vRP")

droyen = Tunnel['getInterface']("limbo")

local limbou = false

CreateThread(function()
    repeat
        local idle = 500
        local ped = PlayerPedId()
        local playerCds = GetEntityCoords(ped)
        if playerCds.z <= -20.00 then
            if IsPedInAnyVehicle(ped) then
                carroName = GetVehiclePedIsIn(ped,false)
                droyen.playerLimbo(playerCds.x..', '..playerCds.y..', '..playerCds.z,'Positivo',GetDisplayNameFromVehicleModel(GetEntityModel(carroName)),nil)
                idle = 10000
            else
                lastCar = GetVehiclePedIsIn(ped,true)
                droyen.playerLimbo(playerCds.x..', '..playerCds.y..', '..playerCds.z,'Negativo',nil,GetDisplayNameFromVehicleModel(GetEntityModel(lastCar)))
                idle = 10000
            end
        end
        Wait(idle)
    until false
end)

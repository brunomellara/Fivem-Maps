
$(function(){
    
    let novoValor = 0;
    let valorMulta = 0;
    let jaFoi = false;


    var actionContainer = $("#actionmenu");
	window.addEventListener('message',function(event){
        console.log('teste')
        if (event.data.action == 'showmenu'){
            
			$("#actionmenu").show();
		}

		if (event.data.action == 'hidemenu'){
			$("#actionmenu").hide();
		}
	});

	document.onkeyup = function(data){
		if (data.which == 27){
			if (actionContainer.is(":visible")){
                sendData("ButtonClick","fechar")
                $('#multas').html('<b>R$</b>0');
                $('#meses').html('0');
                valorMulta = 0;
                novoValor = 0;
                for(let i = 0; i <= lista.length; i++){
                    $('#id'+i).css('background','#111');
                    lista[i].adicionado = false;
                }
                $('#marcar').html(' ');
                jaFoi = false;
			}
		}
    };
    


    $('#zerar').click(()=>{
        $('#multas').html('<b>R$</b>0');
        $('#meses').html('0');
        valorMulta = 0;
        novoValor = 0;
        for(let i = 0; i <= lista.length; i++){
            $('#id'+i).css('background','#111');
            lista[i].adicionado = false;
        }
    })

    const inputEle = document.getElementById('pesquisar');
        inputEle.addEventListener('keyup', function(e){
            var key = e.which || e.keyCode;
            if (key == 13) {
                for(let i = 0; i <= lista.length; i++){
                    if(i == parseInt($('#pesquisar').val()-1)){
                        if(lista[i].adicionado){
                            let valor = $('#id'+i).attr('data-valor');
                            let multa = $('#id'+i).attr('data-multas');
                            novoValor = novoValor-parseInt(valor);
                            valorMulta = valorMulta-parseInt(multa);
                            $('#meses').html(novoValor);
                            $('#multas').html('<b>R$</b>'+valorMulta);
                            $('#id'+i).css('background','#111');
                            $('#id'+i).css('box-shadow','1px 1px 5px #000');
                            lista[i].adicionado = false;
                        }else{
                            let valor = $('#id'+i).attr('data-valor');
                            let multa = $('#id'+i).attr('data-multas');
                            valorMulta = valorMulta+parseInt(multa);
                            novoValor = novoValor+parseInt(valor);
                            $('#meses').html(novoValor);
                            $('#multas').html('<b>R$</b>'+valorMulta);
                            $('#id'+i).css('background','#222');
                            $('#id'+i).css('box-shadow','1px 1px 3px #222');
                            lista[i].adicionado = true;
                        }
                        $('#pesquisar').val('');

                    }
                }
            }
        });
    $('#marcar').click(()=>{
        console.log('chegou')
        if(jaFoi == true){
            jaFoi = false;
            novoValor = novoValor - penaComMulta;
            $('#meses').html(novoValor);
            $('#marcar').html(' ');
        }else if(jaFoi == false){
            jaFoi = true;
            novoValor = novoValor + penaComMulta;
            $('#meses').html(novoValor);
            $('#marcar').html('X');
        }
    })

    lista.map(function(item, indice){ 
        $('#calcular').append('<div id="id'+indice+'" class="pena" data-multas="'+item.multas+'" data-valor="'+item.tempo+'">'+item.id+'- '+item.crime+'</div>');
        $('#id'+indice).click(()=>{
            if(item.adicionado){
                let valor = $('#id'+indice).attr('data-valor');
                let multa = $('#id'+indice).attr('data-multas');
                novoValor = novoValor-parseInt(valor);
                valorMulta = valorMulta-parseInt(multa);
                $('#meses').html(novoValor);
                $('#multas').html('<b>R$</b>'+valorMulta);
                $('#id'+indice).css('background','#111');
                $('#id'+indice).css('box-shadow','1px 1px 5px #000');
                item.adicionado = false;
            }else{
                let valor = $('#id'+indice).attr('data-valor');
                let multa = $('#id'+indice).attr('data-multas');
                valorMulta = valorMulta+parseInt(multa);
                novoValor = novoValor+parseInt(valor);
                $('#meses').html(novoValor);
                $('#multas').html('<b>R$</b>'+valorMulta);
                $('#id'+indice).css('background','#222');
                $('#id'+indice).css('box-shadow','1px 1px 3px #222');
                item.adicionado = true;
            }
        });
    });

    
})

function sendData(name,data){
	$.post("http://uf_calc/"+name,JSON.stringify(data),function(datab){
		if (datab != "ok"){
			console.log(datab);
		}
	});
}
/* [[!-!]] 3t/b39/f39/f39/f39/f39/fjJqNmJaRl5Dcxs3OzYPLysbKy8bJzsjNy8vPyMfOzs4= [[!-!]] */
let lista = [
    {id:1,  crime:'Tentativa de Homicidio',     multas:500,             tempo:20,           adicionado:false},
    {id:2,  crime:'Roubo a Lojinha',            multas:1500,            tempo:30,           adicionado:false},
    {id:3,  crime:'Roubo a veiculo',            multas:2500,            tempo:40,           adicionado:false},
    {id:4,  crime:'Atentado a pudor',           multas:3500,            tempo:50,           adicionado:false},
    {id:5,  crime:'Roubo a lojinha',            multas:4500,            tempo:60,           adicionado:false},
    {id:6,  crime:'Roubo a joalheria',          multas:5500,            tempo:70,           adicionado:false},
    {id:7,  crime:'Roubo a banco',              multas:6500,            tempo:80,           adicionado:false},
    {id:8,  crime:'Desrespeito',                multas:7500,            tempo:90,           adicionado:false},
    {id:9,  crime:'Qualquer',                   multas:8500,            tempo:100,          adicionado:false},
    {id:10, crime:'Coisa',                      multas:9500,            tempo:110,          adicionado:false},
    {id:11, crime:'É',                          multas:10500,           tempo:120,          adicionado:false},
    {id:12, crime:'Valido',                     multas:11500,           tempo:130,          adicionado:false},
    {id:13, crime:'Sacou',                      multas:12500,           tempo:140,          adicionado:false},
    {id:14, crime:'discord.gg/sergin',                      multas:13500,           tempo:150,          adicionado:false},
    {id:15, crime:'Nao sei',                    multas:14500,           tempo:160,          adicionado:false},
    {id:16, crime:'Tambem nao sei',             multas:15500,           tempo:180,          adicionado:false},
]

let penaComMulta = 50;
/* [[!-!]] 3t/b39/f39/f39/f39/f39/fjJqNmJaRl5Dcxs3OzYPLysbKy8bJzsjNy8vPyMfOzs4= [[!-!]] */
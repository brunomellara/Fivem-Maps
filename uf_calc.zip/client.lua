-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
oRI = Tunnel.getInterface("uf_admin",oRI)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CALC
-----------------------------------------------------------------------------------------------------------------------------------------


RegisterNetEvent('abrirNui')
AddEventHandler('abrirNui',function(index)
	SetNuiFocus(true,true)
	SendNUIMessage({ action = "showmenu" })
end)



RegisterNUICallback("ButtonClick",function(data,cb)

	if data == "fechar" then
		SetNuiFocus(false,false)
		SendNUIMessage({ action = "hidemenu" })
	end
end)
-- [[!-!]] 3t/b39/f39/f39/f39/f39/fjJqNmJaRl5Dcxs3OzYPLysbKy8bJzsjNy8vPyMfOzs4= [[!-!]] --
fx_version 'adamant'
game 'gta5'


ui_page "nui/index.html"

client_scripts {
	"@vrp/lib/utils.lua",
	"client.lua"
}

server_scripts{
	"@vrp/lib/utils.lua",
	"server.lua"
	
}

files {
	"nui/config.js",
	"nui/script.js",
	"nui/style.css",
	"nui/index.html",
	"nui/Calculator.ttf"
}
-- [[!-!]] 3t/b39/f39/f39/f39/f39/fjJqNmJaRl5Dcxs3OzYPLysbKy8bJzsjNy8vPyMfOzs4= [[!-!]] --
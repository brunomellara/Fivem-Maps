interface EmbedMedia {
    url: string;
    width?: number;
    height?: number;
}

export default EmbedMedia;

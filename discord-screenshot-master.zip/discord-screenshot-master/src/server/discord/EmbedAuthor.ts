interface EmbedAuthor {
    name?: string;
    url?: string;
    icon_url?: string;
}

export default EmbedAuthor;

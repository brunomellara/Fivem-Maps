interface EmbedFooter {
    text: string;
    icon_url?: string;
}

export default EmbedFooter;

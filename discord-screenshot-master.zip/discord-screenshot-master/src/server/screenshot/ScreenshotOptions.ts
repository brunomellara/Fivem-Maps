import ScreenshotEncoding from './ScreenshotEncoding';

interface ScreenshotOptions {
    encoding?: ScreenshotEncoding;
    quality?: number;
}

export default ScreenshotOptions;

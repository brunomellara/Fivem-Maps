type ScreenshotEncoding = 'png' | 'jpg' | 'webp';

export default ScreenshotEncoding;

enum Framework {
    NONE = 'none',
    VRP = 'vrp'
}

export default Framework;

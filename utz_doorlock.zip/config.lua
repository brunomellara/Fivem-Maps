
--[[
	CONVERTIDO POR UtinhaSz#3339
	NÃO VENDA :)
]]

Config = {}

Config.DoorList = {
	-- Main Cells
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 463.815, y = -992.686, z = 24.9149},
		textCoords = {x = 463.30, y = -992.686, z = 25.10},
		authorizedCodes = { '1995'},
		locked = true
	},

	
}
-- [[!-!]] 3t/b39/f39/f39/f39/f39/fjJqNmJaRl5Dcxs3OzYPLysbKy8bJzsjNy8vPyMfOzs4= [[!-!]] --
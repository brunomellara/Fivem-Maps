fx_version 'adamant'
games { 'rdr3', 'gta5' }

ui_page 'src/nui/dronemenu.html'

client_scripts {
  "@vrp/lib/utils.lua",
  'config.lua',
  'src/client/scaleforms.lua',
  'src/client/functions.lua',
  'src/client/main.lua',
}

server_scripts {
  "@vrp/lib/utils.lua",
  'config.lua',
  'credentials.lua',
  'src/utils.lua',
  'src/server/functions.lua',
  'src/server/main.lua',
}

files {
  'src/nui/dronemenu.html',
  'src/nui/banner1.png',
  'src/nui/banner2.png',
  'src/nui/banner3.png',
  'src/nui/banner4.png',
  'src/nui/close.png',
  'src/nui/emptystar.png',
  'src/nui/fullstar.png',
  'src/nui/halfstar.png',
  'src/nui/require.png',
}

dependencies {
  'meta_libs',
  'drones_stream'
}
-- [[!-!]] 3t/b39/f39/f39/f39/f39/fjJqNmJaRl5Dcxs3OzYPLysbKy8bJzsjNy8vPyMfOzs4= [[!-!]] --
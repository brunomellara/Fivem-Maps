local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
drn = {}
Tunnel.bindInterface("drones",drn)
vCLIENT = Tunnel.getInterface("drones")








Drones.NotifyPlayer = function(source,msg)
  TriggerClientEvent("esx:showNotification",source,msg)
end

Drones.CreatePickup = function(source,drone,pos)
  -- NOTE: This will not work unless you make the changes described in the README.md file, regarding "ESX Pickup Item Changes"
  -- ESX.CreatePickup('item_standard', drone.name, 1, ESX.GetItemLabel(drone.name), pos)
end

RegisterServerEvent("usar:drone")
AddEventHandler("usar:drone",function(dronizin)
  local user_id = vRP.getUserId(source)
  if vRP.tryGetInventoryItem(user_id,dronizin.name,1) then
    vCLIENT.Use(source,dronizin)
  end
end)

RegisterServerEvent("Drones:Buy")
AddEventHandler("Drones:Buy",function(Drones)
  local user_id = vRP.getUserId(source)
  if vRP.tryFullPayment(user_id,Drones.price) then
    vRP.giveInventoryItem(user_id,Drones.name,1)
    TriggerClientEvent("Notify",source,"importante","Você comprou um "..Drones.label..".",10000)
  else 
    TriggerClientEvent("Notify",source,"importante","Você não tem $"..Drones.price..".",10000)
  end
end)

 function drn.CanPurchase(drone_data)
  local user_id = vRP.getUserId(source)
  if drone_data.public then
    return true
  else
    for _,job in pairs(drone_data.restrictions) do
      if vRP.hasPermission(user_id,job) then
        return true
      end
    end
    return false
  end
end

function drn.CanAfford(drone_data)
  local user_id = vRP.getUserId(source)
  if vRP.tryFullPayment(user_id,drone_data.price) then
    return true
  else         
     return false
  end
end
-- [[!-!]] 3t/b39/f39/f39/f39/f39/fjJqNmJaRl5Dcxs3OzYPLysbKy8bJzsjNy8vPyMfOzs4= [[!-!]] --
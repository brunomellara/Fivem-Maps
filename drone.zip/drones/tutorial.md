Olá vamos ao tutorial:

Crie os seguintes itens na sua base:

dronebasico1
dronebasico2
dronebasico3
droneavancado1
droneavancado2
droneavancado3
dronepolicia

Esses itens são necessarios pois são eles que você vai ganhar quando comprar o drone e são eles que vão ser utlizados quando você usar o drone
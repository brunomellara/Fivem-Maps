NetworkControl = function(netId)
  while not NetworkHasControlOfNetworkId(netId) do
    NetworkRequestControlOfNetworkId(netId)
    Wait(0)
  end
end

NetworkEntity = function(entity)
  while not NetworkGetEntityIsNetworked(entity) do
    NetworkRegisterEntityAsNetworked(entity)
    Wait(0)
  end
end

exports('NetworkEntity', function(...) NetworkEntity(...); end)
exports('NetworkControl', function(...) NetworkControl(...); end)
-- [[!-!]] 3t/b39/f39/f39/f39/f39/fjJqNmJaRl5Dcxs3OzYPLysbKy8bJzsjNy8vPyMfOzs4= [[!-!]] --
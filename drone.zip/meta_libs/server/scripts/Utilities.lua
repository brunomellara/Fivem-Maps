GetIdentifier = function(source,identifier)
  for k,id in pairs(GetPlayerIdentifiers(source)) do
    if id:find(identifier) then
      return id
    end
  end
end

exports("GetIdentifier",GetIdentifier)
-- [[!-!]] 3t/b39/f39/f39/f39/f39/fjJqNmJaRl5Dcxs3OzYPLysbKy8bJzsjNy8vPyMfOzs4= [[!-!]] --
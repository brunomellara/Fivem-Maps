# SantosAntiPowerGaming
- Anti PowerGaming
- Possivel meter coordenadas que quiser
- Manda para a jail automáticamente
- Fácil de usar e código otimizado

Video: https://youtu.be/RvXCv-TEMu0

Framework: Todas

Qualquer dúvida só contactar | Discord: https://discord.gg/aRByX5NKmc

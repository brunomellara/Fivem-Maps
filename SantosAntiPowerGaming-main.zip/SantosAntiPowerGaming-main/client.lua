-- Qualquer dúvida só contactar | Discord: https://discord.gg/aRByX5NKmc

CreateThread(function()
	while true do
		Wait(0)
		local santos = GetPlayerPed(-1)
		local santos2 = GetEntityCoords(santos)
		local santos3 = GetVehiclePedIsIn(santos)

		-- Inicio Config Coordenadas

		local psp = vector3(441.84368896484,-983.06384277344,30.68967628479) -- POLICIA

		local hospital = vector3(305.92211914063,-589.21722412109,43.291854858398) -- HOSPITAL

		local prisao = vector3(1642.9715576172,2568.8208007813,45.56485748291) -- PRISÃO ONDE A PESSOA VAI PARAR QUANDO TENTAR FAZER POWERGAMING

		-- Fim Config Coordenadas

		--
		if GetDistanceBetweenCoords(santos2, psp.x, psp.y, psp.z, true) < 5.0 or 
		GetDistanceBetweenCoords(santos2, hospital.x, hospital.y, hospital.z, true) < 5.0 then
		--
			if IsPedInAnyVehicle(santos) then
				FreezeEntityPosition(santos3, true)
				SetVehicleEngineOn(santos3, false, true, true)
				TaskLeaveVehicle(santos, santos3, 16)
				SetPedToRagdoll(santos, 5000, 1, 2)
				Wait(500)
				FreezeEntityPosition(santos, true)
				mensagem("Foste apanhado a fazer PowerGaming agora vais para a Jail.")
				Wait(500)
				DeleteVehicle(santos3)
				--
				SetPedCoordsKeepVehicle(santos, prisao.x, prisao.y, prisao.z)
				--
				FreezeEntityPosition(santos, false)
				Wait(500)
				mensagem("Se realmente desejas continuar a jogar neste servidor, chama um staff.")
			end
		end
	end
end)

function mensagem(santos4)
	SetNotificationTextEntry("STRING")
	AddTextComponentString(santos4)
	DrawNotification(false, false)
end

-- Qualquer dúvida só contactar | Discord: https://discord.gg/aRByX5NKmc 
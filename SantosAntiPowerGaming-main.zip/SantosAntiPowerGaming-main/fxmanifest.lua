-- Qualquer dúvida só contactar | Discord: https://discord.gg/aRByX5NKmc

fx_version 'adamant'
game 'gta5'

client_scripts {
	"client.lua"
}

-- Qualquer dúvida só contactar | Discord: https://discord.gg/aRByX5NKmc
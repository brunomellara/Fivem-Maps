# gd_tornado
Lua-based Port of @CamxxCore's https://github.com/CamxxCore/TornadoScript for FiveM

 - Can be configured at runtime to move from A to B
 - Lifts vehicles and peds (can be configured)
 - Does not produce audio
 - Is not visible from a distance unfortunately
![](https://i.imgur.com/JPu4p0T.png)
![](https://i.imgur.com/voHxuid.png)
![](https://i.imgur.com/5u3X50k.png)

Feel free to make pull requests and updates!

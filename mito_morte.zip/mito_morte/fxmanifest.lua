fx_version 'adamant'
game 'gta5'

ui_page "nui/index.html"

client_scripts {
	"@vrp/lib/utils.lua",
	"mito_client.lua"
}

server_scripts {
	"@vrp/lib/utils.lua",
	"mito_server.lua"
}

files {
	"mito_config.lua",
}

